# G1' gate: ROM vs ANSYS truth on NON-UNIFORM / PRUNED layouts (Phase 5.4).
# For each layout x angle: load ROM bin (3-plane) and ANSYS bin (3-plane),
# compute w-field cosine and slope-RMS amplitude ratio.
# Gate (uniform-band-relative): the nonuniform layout's fidelity must sit
# within the band the ROM achieves on the UNIFORM m05 layout at the same
# angle (cos >= baseline_cos - 0.05, amp ratio within +/-25% of baseline),
# because the ROM's generic field fidelity is angle-dependent (known limits:
# 80deg cos ~0.77 even on uniform layouts).
#
#   python scripts/g1p_nonuniform_truth.py \
#       --rom-root build/_g1p/rom --truth-root data_proxy_g1p \
#       --layouts p1_shift1bolt,p2_pruned79,p3_lines20pct --angles 10 30 58 80
import os, sys, argparse
import numpy as np

G = 32


def load_bin(d, a):
    return np.fromfile(f"{d}/gravity_{a}deg.bin", dtype=np.float32).reshape(3, G, G)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rom-root", default="build/_g1p/rom")
    ap.add_argument("--truth-root", default="data_proxy_g1p")
    ap.add_argument("--layouts", default="p1_shift1bolt,p2_pruned79,p3_lines20pct")
    ap.add_argument("--angles", type=int, nargs="+", default=[10, 30, 58, 80])
    ap.add_argument("--baseline-rom", default="build/_t0_replay/m05",
                    help="uniform m05 ROM dir (generic-fidelity baseline)")
    ap.add_argument("--baseline-truth", default="data_proxy_margin/7x5_margin05_fine",
                    help="uniform m05 ANSYS fine-substep truth dir")
    args = ap.parse_args()

    layouts = args.layouts.split(",")
    # uniform-layout generic fidelity band (what the ROM achieves on the
    # standard layout at the same angles) — the reference band for nonuniform
    base = {}
    for a in args.angles:
        rom_b = load_bin(args.baseline_rom, a)
        tru_b = load_bin(args.baseline_truth, a)
        w_r = rom_b[0].astype(np.float64).ravel()
        w_t = tru_b[0].astype(np.float64).ravel()
        cos = float(w_r @ w_t / np.linalg.norm(w_r) / np.linalg.norm(w_t))
        s_r = float(np.sqrt(np.mean(rom_b[1] ** 2 + rom_b[2] ** 2)))
        s_t = float(np.sqrt(np.mean(tru_b[1] ** 2 + tru_b[2] ** 2)))
        base[a] = (cos, s_t / max(s_r, 1e-30))
    print("uniform m05 generic band: "
          + "  ".join(f"{a}: cos={c:.3f} amp={r:.3f}" for a, (c, r) in base.items()))

    all_ok = True
    print(f"\n{'layout':<18s} {'angle':>5s} {'cos':>8s} {'amp':>7s} {'Dcos':>7s}  verdict")
    for lay in layouts:
        for a in args.angles:
            rom_b = load_bin(os.path.join(args.rom_root, lay), a)
            tru_b = load_bin(os.path.join(args.truth_root, lay), a)
            w_r = rom_b[0].astype(np.float64).ravel()
            w_t = tru_b[0].astype(np.float64).ravel()
            cos = float(w_r @ w_t / np.linalg.norm(w_r) / np.linalg.norm(w_t))
            slp_r = float(np.sqrt(np.mean(rom_b[1] ** 2 + rom_b[2] ** 2)))
            slp_t = float(np.sqrt(np.mean(tru_b[1] ** 2 + tru_b[2] ** 2)))
            ratio = slp_t / max(slp_r, 1e-30)
            bc, br = base[a]
            # gate: within the generic band — cos no worse than baseline -0.05,
            # amplitude ratio within +/-25% around the baseline ratio
            ok = cos > bc - 0.05 and br * 0.75 <= ratio <= br * 1.25
            all_ok &= ok
            print(f"{lay:<18s} {a:>5d} {cos:8.4f} {ratio:7.3f} {cos-bc:+7.3f}  "
                  f"{'OK' if ok else 'FAIL'}")
    print(f"\nG1' gate (uniform-band-relative): {'PASS' if all_ok else 'FAIL'}")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
