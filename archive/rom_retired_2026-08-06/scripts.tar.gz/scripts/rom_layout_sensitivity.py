# A1 / G0 gate: ROM layout sensitivities via the implicit function theorem.
#
# Linear plate (exact):
#   K(pi) d = q f(pi)  ->  dd/dpi = Kff^-1 (q df/dpi - dK/dpi . d)
#   dK_e/dpi, df_e/dpi via complex-step on the element geometry (ax, bx);
#   d(mesh)/dpi from the make_mesh provenance tables (PlateROM.src_x/src_z).
#
# von Karman (v1 FROZEN coupling): at the converged state (d_b, d_m) the
# bending step solves (K + Kg) d_b = q_n f. We freeze d_m and the state
# dependence of Kg, differentiating only through mesh geometry:
#   dd_b/dpi ~= (K+Kg)ff^-1 (q_n df/dpi - d(K+Kg)/dpi . d_b)
# This misses the membrane feedback (dKm/dpi, dfm/dpi, d_m coupling);
# the G0 FD check below decides whether the approximation meets <10%.
#
# FD reference: central difference on the 32x32 render surface after
# rebuilding the perturbed mesh (field-level end-to-end check).
#
#   python scripts/rom_layout_sensitivity.py --margin 0.05 --mode linear --angle 10
#   python scripts/rom_layout_sensitivity.py --bolt-layout <json> --mode vk --angle 10
import os, sys, argparse
import numpy as np
from scipy import sparse
from scipy.sparse import linalg as spla

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rom_plate_fem as rom
import layout_utils as lu

CS_EPS = 1e-30  # complex-step epsilon


# ------------------------------------------------------- element derivatives
def elem_bending_derivs(ax, bx):
    """dK_e/d(ax,bx), df_e/d(ax,bx) via complex step (exact to machine eps)."""
    K1, f1 = rom.acm_element(ax + 1j * CS_EPS, bx, rom.D_PLATE)
    K2, f2 = rom.acm_element(ax, bx + 1j * CS_EPS, rom.D_PLATE)
    return (K1.imag / CS_EPS, K2.imag / CS_EPS,
            f1.imag / CS_EPS, f2.imag / CS_EPS)


def elem_geometric(ax, bx, d_e, u_e):
    """Kg_e for one element (replicates PlateVK._geometric_stiffness inner)."""
    Ke = np.zeros((12, 12), dtype=np.result_type(ax, bx, d_e, u_e, np.float64))
    for ii in range(3):
        for jj in range(3):
            xi, eta = rom._GPT[ii], rom._GPT[jj]
            wgt = rom._GWT[ii] * rom._GWT[jj] * ax * bx
            Gm = rom.acm_Nd(xi, eta, ax, bx)
            wx = Gm[0] @ d_e
            wy = Gm[1] @ d_e
            eps = rom.q4_Bm(xi, eta, ax, bx) @ u_e \
                + np.array([0.5 * wx * wx, 0.5 * wy * wy, wx * wy])
            N = rom.THK * rom._CHAT @ eps
            Nm = np.array([[N[0], N[2]], [N[2], N[1]]])
            Ke += wgt * Gm.T @ Nm @ Gm
    return Ke


def elem_geometric_derivs(ax, bx, d_e, u_e):
    K1 = elem_geometric(ax + 1j * CS_EPS, bx, d_e, u_e)
    K2 = elem_geometric(ax, bx + 1j * CS_EPS, d_e, u_e)
    return K1.imag / CS_EPS, K2.imag / CS_EPS


def elem_membrane(ax, bx):
    """Q4 membrane element stiffness (8x8) and in-plane UDL load (8,),
    replicating PlateVK.__init__ inner loop."""
    dt = np.result_type(ax, bx, np.float64)
    Ke = np.zeros((8, 8), dtype=dt)
    fe = np.zeros(8, dtype=dt)
    for ii in range(3):
        for jj in range(3):
            xi, eta = rom._GPT[ii], rom._GPT[jj]
            wgt = rom._GWT[ii] * rom._GWT[jj] * ax * bx
            Bm = rom.q4_Bm(xi, eta, ax, bx)
            Ke += wgt * rom.THK * Bm.T @ rom._CHAT @ Bm
            fe[1::2] += wgt * rom.q4_N(xi, eta)
    return Ke, fe


def elem_membrane_derivs(ax, bx):
    K1, f1 = elem_membrane(ax + 1j * CS_EPS, bx)
    K2, f2 = elem_membrane(ax, bx + 1j * CS_EPS)
    return K1.imag / CS_EPS, K2.imag / CS_EPS, f1.imag / CS_EPS, f2.imag / CS_EPS


def elem_nl_rhs(ax, bx, d_e):
    """von Karman nonlinear membrane rhs of one element (8,),
    replicating PlateVK._nl_mem_rhs inner loop."""
    re = np.zeros(8, dtype=np.result_type(ax, bx, d_e, np.float64))
    for ii in range(3):
        for jj in range(3):
            xi, eta = rom._GPT[ii], rom._GPT[jj]
            wgt = rom._GWT[ii] * rom._GWT[jj] * ax * bx
            Gm = rom.acm_Nd(xi, eta, ax, bx)
            wx, wy = Gm[0] @ d_e, Gm[1] @ d_e
            enl = np.array([0.5 * wx * wx, 0.5 * wy * wy, wx * wy])
            Nnl = rom.THK * rom._CHAT @ enl
            re += wgt * rom.q4_Bm(xi, eta, ax, bx).T @ Nnl
    return re


def elem_nl_derivs(ax, bx, d_e):
    r1 = elem_nl_rhs(ax + 1j * CS_EPS, bx, d_e)
    r2 = elem_nl_rhs(ax, bx + 1j * CS_EPS, d_e)
    return r1.imag / CS_EPS, r2.imag / CS_EPS


def elem_tangents(ax, bx, d_e, u_e):
    """Joint-Jacobian element blocks via complex steps on the STATE:
    T1 = d(Kg_e d_e)/dd_e (12x12), T2 = d(Kg_e d_e)/du_e (12x8),
    T3 = d(nl_e)/dd_e (8x12)."""
    dt = np.float64
    T1 = np.zeros((12, 12))
    T2 = np.zeros((12, 8))
    T3 = np.zeros((8, 12))
    for c in range(12):
        dc = d_e.astype(complex); dc[c] += 1j * CS_EPS
        T1[:, c] = (elem_geometric(ax, bx, dc, u_e) @ dc).imag / CS_EPS
        T3[:, c] = elem_nl_rhs(ax, bx, dc).imag / CS_EPS
    for c in range(8):
        uc = u_e.astype(complex); uc[c] += 1j * CS_EPS
        T2[:, c] = (elem_geometric(ax, bx, d_e, uc) @ d_e).imag / CS_EPS
    return T1, T2, T3


# ------------------------------------------------------- mesh gradient
def mesh_gradient(plate, dim, idx):
    """d(node line coords)/d(pi) for param (dim='x'|'z', idx=bolt line index)."""
    if dim == "x":
        g = np.array([dict(s).get(idx, 0.0) for s in plate.src_x])
        return g, np.zeros(plate.nz)
    g = np.array([dict(s).get(idx, 0.0) for s in plate.src_z])
    return np.zeros(plate.nx), g


def list_params(plate):
    return ([("x", i) for i in range(len(plate.bpx))]
            + [("z", i) for i in range(len(plate.bpz))])


# ------------------------------------------------------- analytic chain
def ddpi_linear(plate, q, dim, idx, precomp):
    """Exact dd/dpi for the linear plate solve (PlateROM.solve)."""
    gx, gz = mesh_gradient(plate, dim, idx)
    rhs = np.zeros(plate.ndof)
    for (i, j, ax, bx, dofs), (dK_dax, dK_dbx, df_dax, df_dbx) in zip(plate.elem, precomp):
        dax = (gx[i + 1] - gx[i]) / 2.0
        dbx = (gz[j + 1] - gz[j]) / 2.0
        d_e = plate.d[dofs]
        dKd = (dK_dax * dax + dK_dbx * dbx) @ d_e
        dfd = df_dax * dax + df_dbx * dbx
        for a in range(12):
            rhs[dofs[a]] += q * dfd[a] - dKd[a]
    out = np.zeros(plate.ndof)
    out[plate.free] = plate.solve_lu(rhs[plate.free])
    return out


def ddpi_vk_frozen(vk, q_n, dim, idx, precomp, precomp_kg, solve_kg):
    """Frozen-coupling dd_b/dpi for the VK solve at the converged state."""
    gx, gz = mesh_gradient(vk, dim, idx)
    rhs = np.zeros(vk.ndof)
    for ((i, j, ax, bx, dofs), (dK_dax, dK_dbx, df_dax, df_dbx),
         (_, _, _, dofs_m), (dKg_dax, dKg_dbx)) in zip(
            vk.elem, precomp, vk.elem_m, precomp_kg):
        dax = (gx[i + 1] - gx[i]) / 2.0
        dbx = (gz[j + 1] - gz[j]) / 2.0
        d_e = vk.d[dofs]
        dKd = (dK_dax * dax + dK_dbx * dbx + dKg_dax * dax + dKg_dbx * dbx) @ d_e
        dfd = df_dax * dax + df_dbx * dbx
        for a in range(12):
            rhs[dofs[a]] += q_n * dfd[a] - dKd[a]
    out = np.zeros(vk.ndof)
    out[vk.free] = solve_kg(rhs[vk.free])
    return out


# ------------------------------------------------------- VK joint Jacobian
def vk_joint_setup(vk):
    """Assemble the coupled-residual Jacobian at the converged VK state and
    return a context dict with the factorized J plus per-element geometry
    derivative precomputes.

    Residuals at the fixed point (R_b; R_m) = 0:
      R_b = (K + Kg(d_b, d_m)) d_b - q_n f
      R_m = Km d_m - q_in fm + nl(d_b)
    Blocks (element-local complex steps on the state):
      J_bb = K + d(Kg d_b)/dd_b,  J_bm = d(Kg d_b)/dd_m,
      J_mb = d(nl)/dd_b,          J_mm = Km."""
    ndof, ndm = vk.ndof, vk.ndm
    rows, cols, vals = [], [], []
    geom_pre = []
    for (i, j, ax, bx, dofs), (axm, bxm, dofs_b, dofs_m) in zip(vk.elem, vk.elem_m):
        d_e = vk.d[dofs_b]
        u_e = vk.d_m[dofs_m]
        K_e, f_e = rom.acm_element(ax, bx, rom.D_PLATE)
        T1, T2, T3 = elem_tangents(ax, bx, d_e, u_e)
        Km_e, fm_e = elem_membrane(ax, bx)
        dKg = elem_geometric_derivs(ax, bx, d_e, u_e)
        dKm = elem_membrane_derivs(ax, bx)
        dnl = elem_nl_derivs(ax, bx, d_e)
        geom_pre.append((dKg, dKm, dnl))
        Jbb = K_e + T1
        for a in range(12):
            for b in range(12):
                rows.append(dofs[a]); cols.append(dofs[b]); vals.append(Jbb[a, b])
            for b in range(8):
                rows.append(dofs[a]); cols.append(ndof + dofs_m[b]); vals.append(T2[a, b])
        for a in range(8):
            for b in range(12):
                rows.append(ndof + dofs_m[a]); cols.append(dofs[b]); vals.append(T3[a, b])
            for b in range(8):
                rows.append(ndof + dofs_m[a]); cols.append(ndof + dofs_m[b]); vals.append(Km_e[a, b])
    J = sparse.coo_matrix((vals, (rows, cols)),
                          shape=(ndof + ndm, ndof + ndm)).tocsc()
    # The unconstrained J is singular (rigid-body modes); restrict to free
    # DOFs (supports stay at zero displacement, dd/dpi = 0 there).
    free_idx = np.concatenate([vk.free, ndof + vk.free_m])
    solve_j = spla.factorized(J[free_idx][:, free_idx])
    return {"solve_j": solve_j, "geom_pre": geom_pre, "free_idx": free_idx}


def ddpi_vk_joint(vk, q_n, q_in, dim, idx, precomp, ctx):
    """Exact coupled dd_b/dpi via the joint implicit function theorem:
    J [dd_b; dd_m] = -dR/dpi (geometry-only part)."""
    gx, gz = mesh_gradient(vk, dim, idx)
    rhs = np.zeros(vk.ndof + vk.ndm)
    for ((i, j, ax, bx, dofs), (dK_dax, dK_dbx, df_dax, df_dbx),
         (_, _, _, dofs_m), (dKg, dKm, dnl)) in zip(
            vk.elem, precomp, vk.elem_m, ctx["geom_pre"]):
        dax = (gx[i + 1] - gx[i]) / 2.0
        dbx = (gz[j + 1] - gz[j]) / 2.0
        d_e = vk.d[dofs]
        u_e = vk.d_m[dofs_m]
        dKd = (dK_dax * dax + dK_dbx * dbx + dKg[0] * dax + dKg[1] * dbx) @ d_e
        dfd = df_dax * dax + df_dbx * dbx
        dKmd = (dKm[0] * dax + dKm[1] * dbx) @ u_e
        dfmd = dKm[2] * dax + dKm[3] * dbx
        dnld = dnl[0] * dax + dnl[1] * dbx
        for a in range(12):
            rhs[dofs[a]] += q_n * dfd[a] - dKd[a]
        for a in range(8):
            rhs[vk.ndof + dofs_m[a]] += q_in * dfmd[a] - dKmd[a] - dnld[a]
    out = np.zeros(vk.ndof + vk.ndm)
    out[ctx["free_idx"]] = ctx["solve_j"](rhs[ctx["free_idx"]])
    return out[:vk.ndof]
class SurfaceGrad:
    """dw(x,z)/dpi on the fixed 32x32 render grid (full chain)."""

    def __init__(self, plate):
        G = rom.G
        gx_pts = (np.arange(G) + 0.5) / G * rom.W
        gz_pts = (np.arange(G) + 0.5) / G * rom.L
        self.pts = []
        for z in gz_pts:
            for x in gx_pts:
                i = int(np.clip(np.searchsorted(plate.xs, x) - 1, 0, plate.nx - 2))
                j = int(np.clip(np.searchsorted(plate.zs, z) - 1, 0, plate.nz - 2))
                for (ei, ej, ax, bx, dofs) in plate.elem:
                    if ei == i and ej == j:
                        break
                x0, z0 = plate.xs[i], plate.zs[j]
                xi = (x - (x0 + ax)) / ax
                eta = (z - (z0 + bx)) / bx
                # complex-step partials of acm_N
                N_xi = rom.acm_N(xi + 1j * CS_EPS, eta, ax, bx).imag / CS_EPS
                N_eta = rom.acm_N(xi, eta + 1j * CS_EPS, ax, bx).imag / CS_EPS
                N_ax = rom.acm_N(xi, eta, ax + 1j * CS_EPS, bx).imag / CS_EPS
                N_bx = rom.acm_N(xi, eta, ax, bx + 1j * CS_EPS).imag / CS_EPS
                N = rom.acm_N(xi, eta, ax, bx)
                self.pts.append((i, j, xi, eta, ax, bx, dofs, N, N_xi, N_eta, N_ax, N_bx))
        self.plate = plate

    def grad(self, dd, dim, idx):
        """dd = dd/dpi (DOF vector). Returns 32x32 dw/dpi field."""
        gx, gz = mesh_gradient(self.plate, dim, idx)
        out = np.zeros(rom.G * rom.G)
        d = self.plate.d
        for n, (i, j, xi, eta, ax, bx, dofs, N, N_xi, N_eta, N_ax, N_bx) in enumerate(self.pts):
            dax = (gx[i + 1] - gx[i]) / 2.0
            dbx = (gz[j + 1] - gz[j]) / 2.0
            dxi = -(gx[i] + dax + xi * dax) / ax
            deta = -(gz[j] + dbx + eta * dbx) / bx
            dN = N_xi * dxi + N_eta * deta + N_ax * dax + N_bx * dbx
            out[n] = dN @ d[dofs] + N @ dd[dofs]
        return out.reshape(rom.G, rom.G)


# ------------------------------------------------------- drivers
def build_plate(args, bpx, bpz):
    if args.mode == "linear":
        return rom.PlateROM(None, n_bay=args.n_bay, n_over=args.n_over, bpx=bpx, bpz=bpz)
    return rom.PlateVK(None, n_bay=args.n_bay, n_over=args.n_over, bpx=bpx, bpz=bpz)


def solve_plate(plate, args, q_n, q_in, d_b0=None):
    if args.mode == "linear":
        plate.solve(q_n)
        return True
    it, ok = plate.solve_vk(q_n, q_in, d_b0=d_b0, max_iter=120)
    return ok


def analytic_surface_grad(plate, args, q_n, dim, idx, precomp, precomp_kg=None, solve_kg=None, sg=None,
                          q_in=0.0, joint_ctx=None):
    if args.mode == "linear":
        dd = ddpi_linear(plate, q_n, dim, idx, precomp)
    elif args.mode == "vkj":
        dd = ddpi_vk_joint(plate, q_n, q_in, dim, idx, precomp, joint_ctx)
    else:
        dd = ddpi_vk_frozen(plate, q_n, dim, idx, precomp, precomp_kg, solve_kg)
    return sg.grad(dd, dim, idx)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--margin", type=float, default=None)
    ap.add_argument("--bolt-layout", default=None)
    ap.add_argument("--mode", choices=["linear", "vk", "vkj"], default="linear")
    ap.add_argument("--angle", type=float, default=10.0)
    ap.add_argument("--fd-delta", type=float, default=0.01)
    ap.add_argument("--param", default="all", help="x:<i> | z:<i> | all")
    ap.add_argument("--n-bay", type=int, default=4)
    ap.add_argument("--n-over", type=int, default=2)
    args = ap.parse_args()

    if args.bolt_layout:
        layout = lu.load_layout(args.bolt_layout)
        bpx, bpz = lu.positions_lines(layout)
    else:
        m = 0.05 if args.margin is None else args.margin
        bpx = rom.default_bolt_lines(m, 7, rom.W)
        bpz = rom.default_bolt_lines(m, 5, rom.L)

    theta = np.radians(args.angle)
    q_n = rom.Q_AREA * float(np.cos(theta))
    q_in = rom.Q_AREA * float(np.sin(theta))

    plate = build_plate(args, bpx, bpz)
    ok = solve_plate(plate, args, q_n, q_in)
    print(f"[setup] mode={args.mode} angle={args.angle} ndof={plate.ndof} "
          f"nx={plate.nx} nz={plate.nz} vk_ok={ok}")

    # element derivative precomputes
    precomp = [elem_bending_derivs(ax, bx) for (i, j, ax, bx, dofs) in plate.elem]
    precomp_kg, solve_kg, joint_ctx = None, None, None
    if args.mode == "vk":
        precomp_kg = []
        Kg = sparse.lil_matrix((plate.ndof, plate.ndof))
        for (i, j, ax, bx, dofs), (axm, bxm, dofs_b, dofs_m) in zip(plate.elem, plate.elem_m):
            d_e = plate.d[dofs_b]
            u_e = plate.d_m[dofs_m]
            precomp_kg.append(elem_geometric_derivs(ax, bx, d_e, u_e))
            Ke = elem_geometric(ax, bx, d_e, u_e)
            for a in range(12):
                for b in range(12):
                    Kg[dofs[a], dofs[b]] += Ke[a, b]
        Kff = (plate.K + Kg.tocsr())[plate.free][:, plate.free].tocsc()
        solve_kg = spla.factorized(Kff)
    if args.mode == "vkj":
        joint_ctx = vk_joint_setup(plate)

    sg = SurfaceGrad(plate)
    params = list_params(plate)
    if args.param != "all":
        dim, idx = args.param.split(":")
        params = [(dim, int(idx))]

    print(f"{'param':>7s} {'rel_err':>10s} {'cos':>9s} {'|FD|':>10s} {'|AN|':>10s}")
    n_pass = 0
    for dim, idx in params:
        w_an = analytic_surface_grad(plate, args, q_n, dim, idx, precomp,
                                     precomp_kg, solve_kg, sg,
                                     q_in=q_in, joint_ctx=joint_ctx)
        # central FD: rebuild perturbed meshes. Warm-start the VK solve from
        # the base converged state to stay on the SAME equilibrium branch
        # (cold starts can jump branches and produce bogus huge differences).
        delta = args.fd_delta
        fields = []
        conv = []
        for sgn in (+1.0, -1.0):
            if dim == "x":
                bp2 = np.array(bpx, dtype=float); bp2[idx] += sgn * delta
                p2 = build_plate(args, bp2, bpz)
            else:
                bp2 = np.array(bpz, dtype=float); bp2[idx] += sgn * delta
                p2 = build_plate(args, bpx, bp2)
            ok2 = solve_plate(p2, args, q_n, q_in,
                              d_b0=None if args.mode == "linear" else plate.d)
            conv.append(ok2)
            fields.append(p2.surface())
        w_fd = (fields[0] - fields[1]) / (2.0 * delta)
        if not all(conv):
            print(f"{dim}:{idx:<4d} FD NOT CONVERGED (+:{conv[0]} -:{conv[1]}), skipped")
            continue
        num = float(np.linalg.norm(w_an - w_fd))
        den = float(np.linalg.norm(w_fd))
        rel = num / max(den, 1e-30)
        cos = float((w_an.ravel() @ w_fd.ravel())
                    / max(np.linalg.norm(w_an) * den, 1e-300))
        print(f"{dim}:{idx:<4d} {rel:10.3e} {cos:9.5f} {den:10.3e} {np.linalg.norm(w_an):10.3e}")
        n_pass += rel < 0.10
    print(f"\nG0 ({args.mode}): {n_pass}/{len(params)} params rel_err<10% -> "
          f"{'PASS' if n_pass == len(params) else 'CHECK'}")


if __name__ == "__main__":
    main()
