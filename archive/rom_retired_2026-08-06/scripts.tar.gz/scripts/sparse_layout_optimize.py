# B3 v3: sparse bolt-layout outer loop (Phase 5.4 Track B main line).
#
# Protocol: greedy backward elimination with RENDER-LEVEL S95 acceptance.
#   1. ROM provider (--bolt-layout) -> gravity bins + per-layout TPS phi
#   2. renderer: 100-iter Adam on bolt strokes with mild L1 (bolt_l1_lambda)
#      for NEWS 4 mirrors @110dir
#   3. eliminate the bottom-K bolts (max |h| across mirrors); the next render
#      re-optimizes the survivors. Accept the deletion iff
#      total_S95 <= --s95-accept AND regression vs accepted best <= --max-regress;
#      otherwise halve K and retry; stop when even one bolt cannot be removed.
# Phantom-support guard: supports are only removed in the ROM/provider gravity
# field (never just zeroed strokes); every layout change re-solves gravity AND
# regenerates the TPS basis (phi is a cardinal basis of the bolt set).
#
#   python scripts/sparse_layout_optimize.py \
#       --start-layout configs/bolt_layouts/density/11x9_margin05.json \
#       --lambda0 0.1 --prune-per-round 10 --rounds 8
import os, sys, json, csv, argparse, subprocess, time
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXE = os.path.join(ROOT, "build", "src", "Release", "bezier_opt.exe")
PROVIDER = os.path.join(ROOT, "scripts", "rom_field_provider.py")
SUMMARY = "optimization_summary.csv"
MIRRORS = ["North", "East", "South", "West"]

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import layout_utils as lu


def run(cmd, log_path):
    with open(log_path, "w") as lf:
        p = subprocess.run(cmd, cwd=ROOT, stdout=lf, stderr=subprocess.STDOUT)
    return p.returncode


def read_best_bolts(path):
    """Parse {Mirror}_300m_BEST_bolts.txt -> dict idx -> h_pipe (pipeline conv)."""
    h = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            h[int(parts[0])] = float(parts[1])
    return h


def make_layout_json(bx, bz, desc, path):
    lay = {"description": desc,
           "bolt_positions": [[float(x), float(z)] for x, z in zip(bx, bz)],
           "plate_width_m": 12.84, "plate_length_m": 9.45,
           "plate_thickness_m": 0.004,
           "youngs_modulus_pa": 70000000000.0, "poisson_ratio": 0.22,
           "density_kg_m3": 2500, "gravity_m_s2": 9.81,
           "mesh_ndiv_x": 64, "mesh_ndiv_z": 48}
    json.dump(lay, open(path, "w"), indent=2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start-layout", required=True)
    ap.add_argument("--template", default="configs/_fw_tanh_a0_110.json")
    ap.add_argument("--lambda0", type=float, default=0.1,
                    help="mild L1 to separate redundant bolts (S95-neutral)")
    ap.add_argument("--prune-per-round", type=int, default=10)
    ap.add_argument("--rounds", type=int, default=8)
    ap.add_argument("--iters", type=int, default=100)
    ap.add_argument("--s95-accept", type=float, default=291.3,
                    help="acceptance ceiling (ROM-口径 7x5 m05 baseline)")
    ap.add_argument("--max-regress", type=float, default=0.05,
                    help="max relative regression vs accepted best")
    ap.add_argument("--min-bolts", type=int, default=15)
    ap.add_argument("--protect-edge", action="store_true",
                    help="never delete bolts on the outermost lines of the start "
                         "layout (edge-integrity guard: stroke activity measures "
                         "actuator utility, NOT support utility — sparse74 lesson)")
    ap.add_argument("--bins-root", default="data_rom_sparse")
    ap.add_argument("--out-root", default="results_sparse_v3")
    ap.add_argument("--alpha-table", default="analysis/rom_b2_alpha_table_fine.csv")
    args = ap.parse_args()

    tpl = json.load(open(os.path.join(ROOT, args.template)))
    os.makedirs(os.path.join(ROOT, args.bins_root), exist_ok=True)
    os.makedirs(os.path.join(ROOT, args.out_root), exist_ok=True)
    os.makedirs(os.path.join(ROOT, "configs/bolt_layouts/free"), exist_ok=True)

    layout_path = os.path.join(ROOT, args.start_layout)
    # start-layout bolt coordinates (edge-line detection for --protect-edge)
    bx0_edge = lu.bolt_positions(lu.load_layout(layout_path))
    history = []
    accepted = None   # (layout_path, out_dir, total)
    step = 0
    k_del = args.prune_per_round

    for rnd in range(args.rounds):
        lam = args.lambda0
        bins_dir = os.path.join(args.bins_root, f"v3r{rnd:02d}")
        out_dir = os.path.join(args.out_root, f"r{rnd:02d}")
        t0 = time.time()
        layout = lu.load_layout(layout_path)
        bx, bz = lu.bolt_positions(layout)
        n_bolts = len(bx)
        print(f"\n=== round {rnd}: N={n_bolts} lambda={lam:.4g} "
              f"layout={os.path.basename(layout_path)}", flush=True)

        # (1) bins (provider: gravity + per-layout TPS phi)
        if not os.path.exists(os.path.join(ROOT, bins_dir, "gravity_10deg.bin")):
            rc = run([sys.executable, PROVIDER, "--bolt-layout", layout_path,
                      "--out", bins_dir, "--alpha-table", args.alpha_table],
                     os.path.join(ROOT, bins_dir + "_provider.log"))
            if rc != 0:
                print(f"  provider FAILED rc={rc}, abort"); break
        # (2) renderer (warm start from the accepted round via coordinate map)
        cfg = dict(tpl)
        cfg["num_bolts"] = n_bolts
        cfg["num_bolts_x"] = 0  # descriptive only (main path uses bins)
        cfg["num_bolts_z"] = 0
        cfg["bolt_l1_lambda"] = lam
        cfg["influence_data_path"] = bins_dir.replace(os.sep, "/")
        cfg["output_dir"] = out_dir.replace(os.sep, "/")
        cfg["iterations"] = args.iters
        if accepted is None:
            cfg["bolt_init_file"] = ""
        else:
            prev_layout_path, prev_out_dir, _ = accepted
            init_dir = os.path.join(args.out_root, f"r{rnd:02d}_init")
            os.makedirs(os.path.join(ROOT, init_dir), exist_ok=True)
            prev_layout = lu.load_layout(prev_layout_path)
            pbx, pbz = lu.bolt_positions(prev_layout)
            for mir in MIRRORS:
                best = read_best_bolts(os.path.join(
                    ROOT, prev_out_dir, f"{mir}_300m_BEST_bolts.txt"))
                lines = ["# warm start mapped by coordinate",
                         "# idx  h_pipe(m)"]
                for ni in range(n_bolts):
                    d2 = (pbx - bx[ni]) ** 2 + (pbz - bz[ni]) ** 2
                    oi = int(np.argmin(d2))
                    assert d2[oi] < 1e-12, "warm-start coordinate mismatch"
                    lines.append(f"{ni} {best[oi]:.8g}")
                with open(os.path.join(ROOT, init_dir,
                                       f"{mir}_300m_bolt_init.txt"), "w",
                          encoding="utf-8") as f:
                    f.write("\n".join(lines) + "\n")
            cfg["bolt_init_file"] = "auto"
            cfg["bolt_init_dir"] = init_dir.replace(os.sep, "/") + "/"
        os.makedirs(os.path.join(ROOT, out_dir), exist_ok=True)
        cfg_path = os.path.join(ROOT, out_dir, "config.json")
        json.dump(cfg, open(cfg_path, "w"), indent=2)
        rc = run([EXE, "--config", cfg_path],
                 os.path.join(ROOT, out_dir, "run.log"))
        if rc != 0:
            print(f"  renderer FAILED rc={rc}, abort"); break
        # (3) parse summary
        s95 = {}
        with open(os.path.join(ROOT, out_dir, SUMMARY)) as fh:
            for row in csv.DictReader(fh):
                s95[row["Position"]] = float(row["Best_S95(m2)"])
        total = sum(s95.get(m, float("nan")) for m in MIRRORS)
        print(f"  S95: " + " ".join(f"{m}={s95.get(m, float('nan')):.2f}" for m in MIRRORS)
              + f" total={total:.2f}", flush=True)

        # (4) acceptance
        if accepted is None:
            ok = True   # first round (dense start) always accepted as baseline
        else:
            ceiling = min(args.s95_accept,
                          accepted[2] * (1.0 + args.max_regress))
            ok = total <= ceiling
        history.append({"round": rnd, "n_bolts": n_bolts, "lambda": lam,
                        "k_del": k_del, "accepted": int(ok),
                        **{f"s95_{m}": s95.get(m) for m in MIRRORS},
                        "s95_total": total})
        if not ok:
            print(f"  REJECTED (total {total:.2f} > ceiling {ceiling:.2f})", flush=True)
            k_del //= 2
            if k_del < 1:
                print("  converged: cannot delete even 1 bolt within budget")
                break
            print(f"  back off: k_del -> {k_del}, retry from accepted layout")
            layout_path = accepted[0]
            continue
        accepted = (layout_path, out_dir, total)

        # (5) choose next deletion set: bottom-k by max|h| across mirrors
        hmax = np.zeros(n_bolts)
        for mir in MIRRORS:
            best = read_best_bolts(os.path.join(
                ROOT, out_dir, f"{mir}_300m_BEST_bolts.txt"))
            for i in range(n_bolts):
                hmax[i] = max(hmax[i], abs(best[i]))
        # edge-integrity guard: bolts on the outermost lines of the START
        # layout are never deletion candidates
        if args.protect_edge:
            ux = np.unique(np.round(bx0_edge[0], 4))
            uz = np.unique(np.round(bx0_edge[1], 4))
            edge = {ux[0], ux[-1], uz[0], uz[-1]}
            protected = np.array([(round(bx[i], 4) in edge) or (round(bz[i], 4) in edge)
                                  for i in range(n_bolts)])
        else:
            protected = np.zeros(n_bolts, dtype=bool)
        order = [i for i in np.argsort(hmax) if not protected[i]]
        k_eff = min(k_del, n_bolts - args.min_bolts, len(order))
        if k_eff < 1:
            print(f"  reached deletion floor (min_bolts={args.min_bolts} or "
                  f"all remaining protected), stop")
            break
        del_idx = np.array(order[:k_eff])
        keep_idx = np.array([i for i in range(n_bolts) if i not in set(del_idx.tolist())])
        print(f"  delete {len(del_idx)} bolts (max|h| up to "
              f"{hmax[del_idx].max()*1000:.1f}mm) -> N={len(keep_idx)}", flush=True)
        new_path = os.path.join(ROOT, "configs/bolt_layouts/free",
                                f"sparse_v3_round{rnd+1:02d}.json")
        make_layout_json(bx[keep_idx], bz[keep_idx],
                         f"sparse v3 round {rnd+1}: {len(keep_idx)} bolts "
                         f"(from {n_bolts})", new_path)
        layout_path = new_path
        print(f"  round {rnd} done in {time.time()-t0:.0f}s", flush=True)

    # sparse path summary
    out_csv = os.path.join(ROOT, "analysis", "sparse_path_v3.csv")
    if history:
        keys = ["round", "n_bolts", "lambda", "k_del", "accepted",
                "s95_North", "s95_East", "s95_South", "s95_West", "s95_total"]
        with open(out_csv, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=keys)
            w.writeheader()
            w.writerows(history)
        print(f"\n=== sparse path v3 -> {out_csv}")
        for row in history:
            print(f"  r{row['round']}: N={row['n_bolts']} "
                  f"acc={row['accepted']} total={row['s95_total']:.2f}")
    if accepted:
        print(f"\nFINAL accepted: {accepted[0]} total={accepted[2]:.2f}")


if __name__ == "__main__":
    main()
