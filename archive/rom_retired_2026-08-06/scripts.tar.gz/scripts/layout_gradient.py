# A3: render-level layout gradient — contract the renderer's per-sun surface
# gradients (dump_surface_grad) with ROM layout sensitivities (vkj, G0-proven).
#
# Chain per angle bin b (renderer conventions):
#   w_b      = -alpha(theta_b) * ROM surface            (provider w plane)
#   sx_b,sz_b = gauss(1.0) + central diff / dx,dz        (provider slope planes)
#   dL/dpi_k = sum_b [ <G_w[b], dw_b/dpi> + <G_sx[b], dsx_b/dpi> + <G_sz[b], dsz_b/dpi> ]
# where G_*[b] = sum_suns lerp_weight(sun,b) * surfaceGrad_sun (with W/L factors
# converting the shader's dw/du,dw/dv gradients to the bin's dw/dx,dw/dz planes).
#
# Sanity: --check-margin compares dL/dmargin (assembled from line params)
# against the finite difference of a supplied margin curve CSV.
#
#   python scripts/layout_gradient.py --dump-dir results_sparse_v3/r00 \
#       --layout configs/bolt_layouts/density/11x9_margin05.json
import os, sys, json, csv, argparse
import numpy as np
from scipy import ndimage

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rom_plate_fem as rom
import rom_layout_sensitivity as sens
import layout_utils as lu

ANG20 = rom.ANG20
MIRRORS = ["North", "East", "South", "West"]


def load_dumps(dump_dir):
    """Returns per-bin aggregated gradient fields (3 x 20 x 32 x 32):
    [0]=G_w, [1]=G_sx (dw/dx), [2]=G_sz (dw/dz)."""
    G_w = np.zeros((20, rom.G, rom.G))
    G_sx = np.zeros((20, rom.G, rom.G))
    G_sz = np.zeros((20, rom.G, rom.G))
    used = set()
    for mir in MIRRORS:
        bin_path = os.path.join(dump_dir, f"surface_grad_{mir}.bin")
        meta_path = os.path.join(dump_dir, f"surface_grad_{mir}_meta.csv")
        if not os.path.exists(bin_path):
            print(f"  [skip] no dump for {mir} in {dump_dir}")
            continue
        with open(meta_path, encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        n_suns = len(rows)
        data = np.fromfile(bin_path, dtype=np.float32).reshape(n_suns, 3, rom.G, rom.G)
        for k, row in enumerate(rows):
            lo, hi, gt = int(row["lo"]), int(row["hi"]), float(row["gt"])
            for b, wgt in ((lo, 1.0 - gt), (hi, gt)):
                if wgt == 0.0:
                    continue
                used.add(b)
                G_w[b] += wgt * data[k, 0]
                G_sx[b] += wgt * data[k, 1] * rom.W   # dL/d(dw/du) -> dL/d(dw/dx)
                G_sz[b] += wgt * data[k, 2] * rom.L   # dL/d(dw/dv) -> dL/d(dw/dz)
    return G_w, G_sx, G_sz, sorted(used)


def provider_post(dw):
    """w-sensitivity field -> (w, sx, sz) sensitivity fields, provider conv."""
    w_s = ndimage.gaussian_filter(dw, 1.0)
    sx = np.gradient(w_s, axis=1) / (rom.W / rom.G)
    sz = np.gradient(w_s, axis=0) / (rom.L / rom.G)
    return dw, sx, sz


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dump-dir", required=True)
    ap.add_argument("--layout", required=True)
    ap.add_argument("--alpha-table", default="analysis/rom_b2_alpha_table_fine.csv")
    ap.add_argument("--out", default=None, help="CSV for dL/dpi (default stdout)")
    args = ap.parse_args()

    alpha_ang, alpha_val = None, None
    if os.path.exists(args.alpha_table):
        ang, al = [], []
        for line in open(args.alpha_table):
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("angle"):
                continue
            a, v = line.split(",")[:2]
            ang.append(float(a)); al.append(float(v))
        order = np.argsort(ang)
        alpha_ang, alpha_val = np.array(ang)[order], np.array(al)[order]

    G_w, G_sx, G_sz, used_bins = load_dumps(args.dump_dir)
    print(f"loaded dumps: {len(used_bins)} angle bins hit")

    layout = lu.load_layout(args.layout)
    bpx, bpz = lu.positions_lines(layout)
    bx_c, bz_c = lu.bolt_positions(layout)
    pairs = list(zip((bx_c + rom.W / 2.0).tolist(), (bz_c + rom.L / 2.0).tolist()))
    plate = rom.PlateVK(None, n_bay=4, n_over=2, patch_hw=0.3, bpx=bpx, bpz=bpz,
                        bolt_pairs=pairs)
    params = sens.list_params(plate)
    n_params = len(params)
    dL = np.zeros(n_params)

    d_b = None
    for b in used_bins:
        a = ANG20[b]
        alpha = float(np.interp(a, alpha_ang, alpha_val)) if alpha_ang is not None else 1.0
        theta = np.radians(a)
        q_n = rom.Q_AREA * float(np.cos(theta))
        q_in = rom.Q_AREA * float(np.sin(theta))
        it, ok = plate.solve_vk(q_n, q_in, d_b0=d_b, max_iter=120)
        if not ok:
            print(f"  [warn] VK not converged @{a}deg, using state anyway")
        d_b = plate.d.copy()
        precomp = [sens.elem_bending_derivs(ax, bx)
                   for (i, j, ax, bx, dofs) in plate.elem]
        jctx = sens.vk_joint_setup(plate)
        sg = sens.SurfaceGrad(plate)
        for k, (dim, idx) in enumerate(params):
            dd = sens.ddpi_vk_joint(plate, q_n, q_in, dim, idx, precomp, jctx)
            dw = -sg.grad(dd, dim, idx) * alpha          # provider w plane
            dwf, dsx, dsz = provider_post(dw)
            dL[k] += float(np.sum(G_w[b] * dwf)
                           + np.sum(G_sx[b] * dsx)
                           + np.sum(G_sz[b] * dsz))
        print(f"  bin {b:2d} ({a:3d}deg, alpha={alpha:.3f}) contracted", flush=True)

    print("\ndL/dpi (per line param):")
    for k, (dim, idx) in enumerate(params):
        print(f"  {dim}:{idx}  {dL[k]:+.6e}")

    # margin sanity assembly: line_i(m) = (m + (1-2m) i/(n-1)) S
    #   => d(line_i)/dm = (1 - 2i/(n-1)) S
    nx, nz = len(bpx), len(bpz)
    dmargin = 0.0
    for k, (dim, idx) in enumerate(params):
        if dim == "x":
            dmargin += dL[k] * (1.0 - 2.0 * idx / (nx - 1)) * rom.W
        else:
            dmargin += dL[k] * (1.0 - 2.0 * idx / (nz - 1)) * rom.L
    print(f"\ndL/dmargin (assembled) = {dmargin:+.4f} m^2 per unit margin")
    print("(compare against FD of a margin curve: dS95/dm between adjacent margins)")

    if args.out:
        with open(args.out, "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["param", "dL"])
            for k, (dim, idx) in enumerate(params):
                w.writerow([f"{dim}:{idx}", f"{dL[k]:.8e}"])
            w.writerow(["margin_assembled", f"{dmargin:.8e}"])
        print("->", args.out)


if __name__ == "__main__":
    main()
