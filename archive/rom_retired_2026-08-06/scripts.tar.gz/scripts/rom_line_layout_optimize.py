# A2: ROM-level line-layout pilot (Phase 5.4 Track A).
# 12 DOF: 7 x-lines + 5 z-lines, softplus-gap parameterization (ordering and
# min-gap guaranteed by construction -> mesh topology fixed -> gradients exist).
# Objective: alpha-scaled ROM gravity slope-RMS (mrad), mean over probe angles.
# Gradient: G0-proven vkj joint sensitivity per line per angle; the objective's
# own dJ/dw comes from per-pixel complex steps (no adjoint derivation needed).
#
#   python scripts/rom_line_layout_optimize.py --iters 30 --angles 10 30 58 80
import os, sys, json, csv, argparse, time
import numpy as np
from scipy import ndimage

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rom_plate_fem as rom
import rom_layout_sensitivity as sens

P_LO = 0.3            # min bolt-line position from plate edge (patch_hw)
D_MIN = 0.8           # min bolt-line gap (2*patch_hw + bay floor)
NX_LINES, NZ_LINES = 7, 5


def softplus(t):
    return np.log1p(np.exp(-np.abs(t))) + np.maximum(t, 0.0)


def inv_softplus(y):
    return y + np.log(-np.expm1(-y)) if y < 20 else y


def gaps_to_lines(g, S):
    """g[0] -> first line offset above P_LO; g[i>=1] -> gap above D_MIN."""
    p = [P_LO + softplus(g[0])]
    for i in range(1, len(g)):
        p.append(p[-1] + D_MIN + softplus(g[i]))
    return np.array(p)


def lines_to_gaps(p):
    g = [inv_softplus(p[0] - P_LO)]
    for i in range(1, len(p)):
        g.append(inv_softplus(p[i] - p[i - 1] - D_MIN))
    return np.array(g)


def dlines_dg(g):
    """Jacobian of line positions w.r.t. gap params (complex-step, 12x12 cheap)."""
    n = len(g)
    J = np.zeros((n, n))
    for c in range(n):
        gc = g.astype(complex); gc[c] += 1j * sens.CS_EPS
        # complex-safe softplus path
        p = [P_LO + np.log1p(np.exp(gc[0]))]
        for i in range(1, n):
            p.append(p[-1] + D_MIN + np.log1p(np.exp(gc[i])))
        J[:, c] = np.array(p).imag / sens.CS_EPS
    return J


def slope_rms_mrad(w):
    """Provider-convention slope RMS (mrad) of a 32x32 w field.
    Complex-safe (no float cast) so per-pixel complex steps work."""
    w_s = ndimage.gaussian_filter(w, 1.0)
    du, dv = np.gradient(w_s, axis=(1, 0))
    du = du / (rom.W / rom.G)
    dv = dv / (rom.L / rom.G)
    return np.sqrt(np.mean(du ** 2 + dv ** 2)) * 1000.0


def dJ_dw(w):
    """d(slope_rms)/dw at each grid pixel (mrad per m), via per-pixel
    complex steps (1024 cheap evals — no hand-derived adjoint needed)."""
    G = rom.G
    grad = np.zeros((G, G))
    for j in range(G):
        for i in range(G):
            wc = w.astype(complex)
            wc[j, i] += 1j * sens.CS_EPS
            grad[j, i] = slope_rms_mrad(wc).imag / sens.CS_EPS
    return grad


class AngleCtx:
    """Per-angle: VK solve + joint setup + per-line surface sensitivities."""

    def __init__(self, plate, angle, alpha):
        self.angle = angle
        self.alpha = alpha
        self.plate = plate
        theta = np.radians(angle)
        self.q_n = rom.Q_AREA * float(np.cos(theta))
        self.q_in = rom.Q_AREA * float(np.sin(theta))
        it, ok = plate.solve_vk(self.q_n, self.q_in, max_iter=120)
        self.converged = ok
        if not ok:
            # cold restart with a longer budget, then linear-plate fallback
            it2, ok2 = plate.solve_vk(self.q_n, self.q_in, d_b0=None, max_iter=240)
            self.converged = ok2
            if not ok2:
                plate.d = np.zeros(plate.ndof)
                plate.d[plate.free] = plate.solve_lu(plate.f[plate.free] * self.q_n)
                plate.d_m = np.zeros(plate.ndm)
        if not self.converged:
            print(f"  [warn] VK not converged @{angle}deg -> "
                  f"{'cold-retry ok' if ok2 else 'linear fallback'}", flush=True)
        self.precomp = [sens.elem_bending_derivs(ax, bx)
                        for (i, j, ax, bx, dofs) in plate.elem]
        self.joint_ctx = sens.vk_joint_setup(plate)
        self.sg = sens.SurfaceGrad(plate)
        self.params = sens.list_params(plate)

    def surface(self):
        return -self.plate.surface() * self.alpha

    def surface_sens(self, dim, idx):
        dd = sens.ddpi_vk_joint(self.plate, self.q_n, self.q_in, dim, idx,
                                self.precomp, self.joint_ctx)
        return -self.sg.grad(dd, dim, idx) * self.alpha


def evaluate(gx, gz, angles, alpha_tab, need_grad):
    """Build plate from gap params, return (objective mrad, grad_x, grad_z, info).
    Angles whose VK solve fails to converge are excluded from BOTH the
    objective mean and the gradient (a non-converged state poisons Adam)."""
    px = gaps_to_lines(gx, rom.W)
    pz = gaps_to_lines(gz, rom.L)
    plate = rom.PlateVK(None, n_bay=4, n_over=2, patch_hw=0.3, bpx=px, bpz=pz)
    obj = 0.0
    grad = np.zeros(len(px) + len(pz))
    infos = []
    n_used = 0
    for a in angles:
        alpha = float(np.interp(a, alpha_tab[0], alpha_tab[1])) if alpha_tab else 1.0
        ctx = AngleCtx(plate, a, alpha)
        w = ctx.surface()
        obj_a = slope_rms_mrad(w)
        infos.append((a, obj_a, ctx.converged))
        if not ctx.converged:
            continue
        n_used += 1
        obj += obj_a
        if need_grad:
            dJ = dJ_dw(w)
            for k, (dim, idx) in enumerate(ctx.params):
                ws = ctx.surface_sens(dim, idx)
                grad[k] += float(np.sum(dJ * ws))
    if n_used > 0:
        obj /= n_used
        grad /= n_used
    # boundary feasibility penalty (last line must leave room for its patch)
    pen = 0.0
    for p, S in ((px, rom.W), (pz, rom.L)):
        viol = p[-1] - (S - P_LO)
        if viol > 0:
            pen += 1e3 * viol ** 2
    return obj + pen, grad, px, pz, infos


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--iters", type=int, default=30)
    ap.add_argument("--angles", type=int, nargs="+", default=[10, 30, 58, 80])
    ap.add_argument("--alpha-table", default="analysis/rom_b2_alpha_table_fine.csv")
    ap.add_argument("--lr", type=float, default=0.1)
    ap.add_argument("--margin0", type=float, default=0.05,
                    help="uniform-grid start margin")
    ap.add_argument("--out", default="analysis/line_layout_traj.csv")
    args = ap.parse_args()

    alpha_tab = None
    if args.alpha_table and os.path.exists(args.alpha_table):
        ang, al = [], []
        for line in open(args.alpha_table):
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("angle"):
                continue
            a, v = line.split(",")[:2]
            ang.append(float(a)); al.append(float(v))
        order = np.argsort(ang)
        alpha_tab = (np.array(ang)[order], np.array(al)[order])

    # uniform start
    px0 = rom.default_bolt_lines(args.margin0, NX_LINES, rom.W)
    pz0 = rom.default_bolt_lines(args.margin0, NZ_LINES, rom.L)
    gx = lines_to_gaps(px0)
    gz = lines_to_gaps(pz0)

    m1 = np.zeros_like(gx); m2 = np.zeros_like(gx)
    m1z = np.zeros_like(gz); m2z = np.zeros_like(gz)
    b1, b2, eps = 0.9, 0.999, 1e-8
    rows = []
    print(f"A2 pilot: {len(args.angles)} angles {args.angles}, start margin={args.margin0}")
    for it in range(args.iters + 1):
        t0 = time.time()
        obj, grad, px, pz, infos = evaluate(gx, gz, args.angles, alpha_tab,
                                            need_grad=it < args.iters)
        Jx = dlines_dg(gx); Jz = dlines_dg(gz)
        gg_x = Jx.T @ grad[:len(px)]
        gg_z = Jz.T @ grad[len(px):]
        print(f"it{it:3d} obj={obj:.4f} mrad "
              f"({' '.join(f'{a}:{v:.3f}' + ('' if ok else '*NC*') for a, v, ok in infos)}) "
              f"|g|={np.hypot(np.linalg.norm(gg_x), np.linalg.norm(gg_z)):.3e} "
              f"[{time.time()-t0:.0f}s]", flush=True)
        rows.append({"iter": it, "obj": obj,
                     **{f"slope_{a}": v for a, v, ok in infos},
                     **{f"px{i}": v for i, v in enumerate(px)},
                     **{f"pz{i}": v for i, v in enumerate(pz)}})
        if it == args.iters:
            break
        # Adam (mild lr decay)
        lr_t = args.lr / (1.0 + it / 20.0)
        for (g, gg, m_1, m_2) in ((gx, gg_x, m1, m2), (gz, gg_z, m1z, m2z)):
            m_1[:] = b1 * m_1 + (1 - b1) * gg
            m_2[:] = b2 * m_2 + (1 - b2) * gg * gg
            mh = m_1 / (1 - b1 ** (it + 1))
            vh = m_2 / (1 - b2 ** (it + 1))
            g -= lr_t * mh / (np.sqrt(vh) + eps)

    keys = list(rows[0].keys())
    with open(args.out, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    print(f"\ntrajectory -> {args.out}")
    print("final x lines:", np.round(px, 4).tolist())
    print("final z lines:", np.round(pz, 4).tolist())
    lay = {"description": f"A2 line-layout pilot result (obj={rows[-1]['obj']:.3f} mrad)",
           "positions_x": [float(v) - rom.W / 2 for v in px],
           "positions_z": [float(v) - rom.L / 2 for v in pz],
           "plate_width_m": rom.W, "plate_length_m": rom.L,
           "plate_thickness_m": rom.THK,
           "youngs_modulus_pa": 70000000000.0, "poisson_ratio": 0.22,
           "density_kg_m3": 2500, "gravity_m_s2": 9.81,
           "mesh_ndiv_x": 64, "mesh_ndiv_z": 48}
    out_json = "configs/bolt_layouts/free/a2_line_layout.json"
    json.dump(lay, open(out_json, "w"), indent=2)
    print("layout ->", out_json)


if __name__ == "__main__":
    main()
