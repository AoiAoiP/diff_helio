# A4: continuous line-position refinement on the render-level S95 gradient.
# Per step: dump surface grads (renderer, optimized state) -> contract with
# ROM vkj line sensitivities (layout_gradient machinery) -> clamped gradient
# step on line positions -> ROM provider bins -> 100-iter renderer eval.
# Accept iff S95 improves; else halve the step. Stops on two rejections.
#
#   python scripts/a4_line_refine.py --layout configs/bolt_layouts/free/v4_best_91.json \
#       --bins data_rom_sparse/v4/v3r01 --init-dir data/init_a4 --steps 4
import os, sys, json, csv, argparse, subprocess, time
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXE = os.path.join(ROOT, "build", "src", "Release", "bezier_opt.exe")
PROVIDER = os.path.join(ROOT, "scripts", "rom_field_provider.py")
SUMMARY = "optimization_summary.csv"
MIRRORS = ["North", "East", "South", "West"]
ANG20 = None

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import layout_utils as lu
import rom_plate_fem as rom
import rom_layout_sensitivity as sens
import layout_gradient as lg
from scipy import ndimage

ANG20 = rom.ANG20
D_MIN = 0.8          # min line gap (anti-collapse, matches mesh guard)
P_LO = 0.3           # min line position from plate edge


def run(cmd, log_path):
    with open(log_path, "w") as lf:
        p = subprocess.run(cmd, cwd=ROOT, stdout=lf, stderr=subprocess.STDOUT)
    return p.returncode


def write_init_from_best(res_dir, init_dir):
    os.makedirs(os.path.join(ROOT, init_dir), exist_ok=True)
    for mir in MIRRORS:
        src = os.path.join(ROOT, res_dir, f"{mir}_300m_BEST_bolts.txt")
        lines = ["# A4 warm start", "# idx  h_pipe(m)"]
        with open(src, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                p = line.split()
                lines.append(f"{p[0]} {p[1]}")
        with open(os.path.join(ROOT, init_dir, f"{mir}_300m_bolt_init.txt"),
                  "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")


def render_eval(layout_path, bins_dir, out_dir, iters, template,
                l1=0.0, init_dir=None, dump=False):
    """Run renderer (4 mirrors) on the given layout's bins; return per-mirror best S95."""
    lay = lu.load_layout(layout_path)
    bx, bz = lu.bolt_positions(lay)
    cfg = dict(template)
    cfg["num_bolts"] = len(bx)
    cfg["num_bolts_x"] = 0
    cfg["num_bolts_z"] = 0
    cfg["influence_data_path"] = bins_dir.replace(os.sep, "/")
    cfg["output_dir"] = out_dir.replace(os.sep, "/")
    cfg["iterations"] = iters
    cfg["bolt_l1_lambda"] = l1
    if init_dir:
        cfg["bolt_init_file"] = "auto"
        cfg["bolt_init_dir"] = init_dir.replace(os.sep, "/") + "/"
    else:
        cfg["bolt_init_file"] = ""
    if dump:
        cfg["dump_surface_grad"] = 1
        cfg["learning_rate"] = 0.0
        cfg["min_learning_rate"] = 0.0
    os.makedirs(os.path.join(ROOT, out_dir), exist_ok=True)
    cfg_path = os.path.join(ROOT, out_dir, "config.json")
    json.dump(cfg, open(cfg_path, "w"), indent=2)
    rc = run([EXE, "--config", cfg_path], os.path.join(ROOT, out_dir, "run.log"))
    if rc != 0:
        raise RuntimeError(f"renderer failed rc={rc} in {out_dir}")
    s95 = {}
    with open(os.path.join(ROOT, out_dir, SUMMARY)) as fh:
        for row in csv.DictReader(fh):
            s95[row["Position"]] = float(row["Best_S95(m2)"])
    return s95


def contract_gradient(layout_path, dump_dir, alpha_tab):
    """dL/d(line position) via A3 machinery. Returns params list + gradient."""
    bpx, bpz = lu.positions_lines(lu.load_layout(layout_path))
    G_w, G_sx, G_sz, used_bins = lg.load_dumps(dump_dir)
    lay = lu.load_layout(layout_path)
    bx_c, bz_c = lu.bolt_positions(lay)
    pairs = list(zip((bx_c + rom.W / 2.0).tolist(), (bz_c + rom.L / 2.0).tolist()))
    plate = rom.PlateVK(None, n_bay=4, n_over=2, patch_hw=0.3,
                        bpx=bpx, bpz=bpz, bolt_pairs=pairs)
    params = sens.list_params(plate)
    dL = np.zeros(len(params))
    d_b = None
    for b in used_bins:
        a = ANG20[b]
        alpha = float(np.interp(a, alpha_tab[0], alpha_tab[1])) if alpha_tab else 1.0
        theta = np.radians(a)
        q_n = rom.Q_AREA * float(np.cos(theta))
        q_in = rom.Q_AREA * float(np.sin(theta))
        it, ok = plate.solve_vk(q_n, q_in, d_b0=d_b, max_iter=120)
        if not ok:
            it2, ok2 = plate.solve_vk(q_n, q_in, d_b0=None, max_iter=240)
            if not ok2:
                plate.d = np.zeros(plate.ndof)
                plate.d[plate.free] = plate.solve_lu(plate.f[plate.free] * q_n)
                plate.d_m = np.zeros(plate.ndm)
        d_b = plate.d.copy()
        precomp = [sens.elem_bending_derivs(ax, bx)
                   for (i, j, ax, bx, dofs) in plate.elem]
        jctx = sens.vk_joint_setup(plate)
        sg = sens.SurfaceGrad(plate)
        for k, (dim, idx) in enumerate(params):
            dd = sens.ddpi_vk_joint(plate, q_n, q_in, dim, idx, precomp, jctx)
            dw = -sg.grad(dd, dim, idx) * alpha
            dwf, dsx, dsz = lg.provider_post(dw)
            dL[k] += float(np.sum(G_w[b] * dwf)
                           + np.sum(G_sx[b] * dsx)
                           + np.sum(G_sz[b] * dsz))
        print(f"    bin {b:2d} ({a}deg) contracted", flush=True)
    return params, dL


def step_layout(layout_path, params, dL, step_m, out_path):
    """Move lines along -dL with max |move| = step_m, clamped to keep gaps."""
    lay = lu.load_layout(layout_path)
    bpx, bpz = lu.positions_lines(lay)
    nx = len(bpx)
    new_px = bpx.copy(); new_pz = bpz.copy()
    gmax = np.max(np.abs(dL))
    if gmax <= 0:
        return False
    for k, (dim, idx) in enumerate(params):
        move = -step_m * dL[k] / gmax
        if dim == "x":
            new_px[idx] += move
        else:
            new_pz[idx] += move
    # clamp: ordering + min gap + plate bounds (sequential projection)
    for arr, S in ((new_px, rom.W), (new_pz, rom.L)):
        arr[0] = max(arr[0], P_LO)
        for i in range(1, len(arr)):
            arr[i] = max(arr[i], arr[i - 1] + D_MIN)
        # if pushed past the far edge, shift back as a block
        overflow = arr[-1] - (S - P_LO)
        if overflow > 0:
            arr -= overflow
        arr[0] = max(arr[0], P_LO)
    if np.allclose(new_px, bpx) and np.allclose(new_pz, bpz):
        return False
    # write lines-form layout (corner-origin -> center-origin)
    new = {"description": f"A4 refined step={step_m}",
           "positions_x": (new_px - rom.W / 2).tolist(),
           "positions_z": (new_pz - rom.L / 2).tolist(),
           "plate_width_m": rom.W, "plate_length_m": rom.L,
           "plate_thickness_m": rom.THK,
           "youngs_modulus_pa": 70000000000.0, "poisson_ratio": 0.22,
           "density_kg_m3": 2500, "gravity_m_s2": 9.81,
           "mesh_ndiv_x": 64, "mesh_ndiv_z": 48}
    # keep free-form bolt list consistent with moved lines: move bolts with their line
    bx_c, bz_c = lu.bolt_positions(lay)
    nbx = bx_c.copy(); nbz = bz_c.copy()
    for idx in range(nx):
        mask = np.isclose(bx_c + rom.W / 2, bpx[idx], atol=1e-6)
        nbx[mask] = new_px[idx] - rom.W / 2
    for idx in range(len(bpz)):
        mask = np.isclose(bz_c + rom.L / 2, bpz[idx], atol=1e-6)
        nbz[mask] = new_pz[idx] - rom.L / 2
    new["bolt_positions"] = [[float(x), float(z)] for x, z in zip(nbx, nbz)]
    json.dump(new, open(out_path, "w"), indent=2)
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--layout", required=True)
    ap.add_argument("--bins", required=True, help="ROM bins dir for the start layout")
    ap.add_argument("--init-dir", required=True, help="warm-start init dir for dump run")
    ap.add_argument("--steps", type=int, default=4)
    ap.add_argument("--step-m", type=float, default=0.05,
                    help="max line move per step (m)")
    ap.add_argument("--iters", type=int, default=100)
    ap.add_argument("--alpha-table", default="analysis/rom_b2_alpha_table_fine.csv")
    ap.add_argument("--template", default="configs/_fw_tanh_a0_110.json")
    ap.add_argument("--out-root", default="results_a4")
    args = ap.parse_args()

    template = json.load(open(os.path.join(ROOT, args.template)))
    ang, al = [], []
    for line in open(os.path.join(ROOT, args.alpha_table)):
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("angle"):
            continue
        a, v = line.split(",")[:2]
        ang.append(float(a)); al.append(float(v))
    order = np.argsort(ang)
    alpha_tab = (np.array(ang)[order], np.array(al)[order])

    layout_path = os.path.join(ROOT, args.layout)
    bins_dir = args.bins
    init_dir = args.init_dir
    step_m = args.step_m
    history = []

    # baseline eval (same protocol as refinement evals)
    base_out = os.path.join(args.out_root, "s00_base")
    if not os.path.exists(os.path.join(ROOT, base_out, SUMMARY)):
        s95 = render_eval(layout_path, bins_dir, base_out, args.iters, template,
                          l1=0.1, init_dir=init_dir)
    else:
        s95 = {}
        with open(os.path.join(ROOT, base_out, SUMMARY)) as fh:
            for row in csv.DictReader(fh):
                s95[row["Position"]] = float(row["Best_S95(m2)"])
    base = sum(s95[m] for m in MIRRORS)
    print(f"[A4] baseline N={len(lu.bolt_positions(lu.load_layout(layout_path))[0])} "
          f"S95={s95} total={base:.2f}", flush=True)
    history.append({"step": 0, "layout": os.path.basename(layout_path),
                    "step_m": 0.0, **{f"s95_{m}": s95[m] for m in MIRRORS},
                    "total": base, "accepted": 1})

    best_layout, best_out, best_total = layout_path, base_out, base
    rejects = 0
    for step in range(1, args.steps + 1):
        print(f"\n[A4] step {step}: dump + gradient contraction", flush=True)
        dump_dir = os.path.join(args.out_root, f"s{step:02d}_dump")
        write_init_from_best(best_out, os.path.join(args.out_root, f"s{step:02d}_init"))
        render_eval(best_layout, bins_dir, dump_dir, 1, template, l1=0.0,
                    init_dir=os.path.join(args.out_root, f"s{step:02d}_init"), dump=True)
        params, dL = contract_gradient(best_layout, os.path.join(ROOT, dump_dir), alpha_tab)
        top = np.argsort(-np.abs(dL))[:5]
        for k in top:
            print(f"    grad {params[k][0]}:{params[k][1]} = {dL[k]:+.4e}", flush=True)
        new_layout = os.path.join(ROOT, "configs/bolt_layouts/free",
                                  f"a4_step{step:02d}.json")
        moved = step_layout(best_layout, params, dL, step_m, new_layout)
        if not moved:
            print("  no effective move (gradient ~0 or clamped), stop", flush=True)
            break
        # bins + eval
        new_bins = os.path.join("data_rom_sparse", f"a4_s{step:02d}")
        rc = run([sys.executable, PROVIDER, "--bolt-layout", new_layout,
                  "--out", new_bins, "--alpha-table", args.alpha_table],
                 os.path.join(ROOT, new_bins + "_provider.log"))
        if rc != 0:
            print("  provider failed, stop", flush=True)
            break
        out_dir = os.path.join(args.out_root, f"s{step:02d}_eval")
        write_init_from_best(best_out, os.path.join(args.out_root, f"s{step:02d}_einit"))
        s95 = render_eval(new_layout, new_bins, out_dir, args.iters, template,
                          l1=0.1, init_dir=os.path.join(args.out_root, f"s{step:02d}_einit"))
        total = sum(s95[m] for m in MIRRORS)
        ok = total < best_total
        print(f"  eval total={total:.2f} vs best {best_total:.2f} -> "
              f"{'ACCEPT' if ok else 'REJECT'}", flush=True)
        history.append({"step": step, "layout": os.path.basename(new_layout),
                        "step_m": step_m, **{f"s95_{m}": s95[m] for m in MIRRORS},
                        "total": total, "accepted": int(ok)})
        if ok:
            best_layout, best_out, best_total = new_layout, out_dir, total
            bins_dir = new_bins
            rejects = 0
        else:
            rejects += 1
            step_m /= 2.0
            if rejects >= 2:
                print("  two consecutive rejects, stop", flush=True)
                break

    out_csv = os.path.join(ROOT, "analysis", "a4_refine_path.csv")
    keys = ["step", "layout", "step_m",
            "s95_North", "s95_East", "s95_South", "s95_West", "total", "accepted"]
    with open(out_csv, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader()
        w.writerows(history)
    print(f"\n[A4] path -> {out_csv}")
    print(f"[A4] BEST: {best_layout} total={best_total:.2f}")


if __name__ == "__main__":
    main()
